export interface Identificable {
    clase:string;
    id: number
}