import { Pacient } from "./Pacient";
import { Empleat } from "./Empleat";

