

namespace index{
// Referències als elements
const idEmpleat: HTMLInputElement = document.getElementById("idEmpleat") as HTMLInputElement;
const nomEmpleat: HTMLInputElement = document.getElementById("nomEmpleat") as HTMLInputElement;
const cognomsEmpleat: HTMLInputElement = document.getElementById("cognomsEmpleat") as HTMLInputElement;
const carrrecEmpleat: HTMLInputElement = document.getElementById("carrrecEmpleat") as HTMLInputElement;
const idPacient: HTMLInputElement = document.getElementById("idPacient") as HTMLInputElement;
const nomPacient: HTMLInputElement = document.getElementById("nomPacient") as HTMLInputElement;
const cognomsPacient: HTMLInputElement = document.getElementById("cognomsPacient") as HTMLInputElement;
const malaltiaPacient: HTMLInputElement = document.getElementById("malaltiaPacient") as HTMLInputElement;
const tractamentPacient: HTMLSelectElement = document.getElementById("tractamentPacient") as HTMLSelectElement;
const idEmpleatEnllac: HTMLInputElement = document.getElementById("idEmpleatEnllac") as HTMLInputElement;
const idPacientEnllac: HTMLInputElement = document.getElementById("idPacientEnllac") as HTMLInputElement;
const idEmpleatPacient: HTMLInputElement = document.getElementById("idEmpleatPacient") as HTMLInputElement;
const sortidaDades = document.getElementById("sortidaDades") as HTMLUListElement;

// Referències butons
const afegirEmpleat: HTMLButtonElement = document.getElementById("afegirEmpleat") as HTMLButtonElement;
const afegirPacient: HTMLButtonElement = document.getElementById("afegirPacient") as HTMLButtonElement;
const enllacarPacient: HTMLButtonElement = document.getElementById("enllacarPacient") as HTMLButtonElement;
const mostrarEmpleats: HTMLButtonElement = document.getElementById("mostrarEmpleats") as HTMLButtonElement;
const mostrarPacients: HTMLButtonElement = document.getElementById("mostrarPacients") as HTMLButtonElement;
const mostrarPacientsEmpleat: HTMLButtonElement = document.getElementById("mostrarPacientsEmpleat") as HTMLButtonElement;

afegirEmpleat.onclick = () => {
    //TODO
};

afegirPacient.onclick = () => {
    //TODO
};

enllacarPacient.onclick = () => {
    //TODO
};

mostrarEmpleats.onclick = () => {
    //TODO
};

mostrarPacients.onclick = () => {
    //TODO
};

mostrarPacientsEmpleat.onclick = () => {
    //TODO
};

}